package tugas.ti.TugasExercise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TugasExerciseApplicationTests {

	@Test
	void contextLoads() {
	}

}
