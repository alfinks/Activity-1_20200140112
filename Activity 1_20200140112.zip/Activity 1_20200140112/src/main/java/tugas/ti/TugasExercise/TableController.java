/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas.ti.TugasExercise;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 *
 * @author Maulana Alfiansyah
 */

@Controller

public class TableController {
    @RequestMapping ("/dataktp")
    //@ResponseBody
    
    public String getTable(Model ktp){
        String result = ("Data Ktp");
        ktp.addAttribute ("Data Ktp", result);
        
        //DataKtp data = new DataKtp();
        ArrayList<List<String>> data = new ArrayList<>();
        
        data.add(0,Arrays.asList("ID","Nomor Ktp", "Nama", "Alamat"));
        
        data.add(1,Arrays.asList("1", "202001","Maulana", "Sumedang"));
        data.add(2,Arrays.asList("2", "202002","Alfiansyah", "Sumedang"));
        data.add(3,Arrays.asList("3", "202003","john", "Brebes"));
        data.add(4,Arrays.asList("4", "202004","Alfin", "Bantul"));
        data.add(5,Arrays.asList("5", "202005","Alam", "Yogyakarta"));
        data.add(6,Arrays.asList("6", "202006","Nopal", "NTB"));
        data.add(7,Arrays.asList("7", "202007","Dimas", "jatinangor"));
        data.add(8,Arrays.asList("8", "202008","Wiratama", "bantul"));
        data.add(9,Arrays.asList("9", "202009","fatur", "Bekasi"));
        data.add(10,Arrays.asList("10", "2020010","irham", "Depok"));
        
        data.add(11,Arrays.asList("11", "2020011","ahmad", "Sumedang utara"));
        data.add(12,Arrays.asList("12", "2020012","yokie", "Sumedang selatan"));
        data.add(13,Arrays.asList("13", "2020013","Althaf", "kasian"));
        data.add(14,Arrays.asList("14", "2020014","steven", "wates"));
        data.add(15,Arrays.asList("15", "2020015","wynona", "jambi"));
        data.add(16,Arrays.asList("16", "2020016","Anya", "ciawi"));
        data.add(17,Arrays.asList("17", "2020017","sasa", "jakarta selatan"));
        data.add(18,Arrays.asList("18", "2020018","Adarnisa", "kemayoran baru"));
        data.add(19,Arrays.asList("19", "2020019","dinda", "kemayoran lama"));
        data.add(20,Arrays.asList("20", "2020020","rifa", "citengah"));
        
        
        
        
        ktp.addAttribute("tabel", data);
        
        return "tableviewer";
        
    }
}